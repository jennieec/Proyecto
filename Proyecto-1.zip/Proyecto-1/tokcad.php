<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>recuperar</title>
    <link rel="stylesheet" href="./olvidecontra.css">
    <head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
    </head>
</head>
<body>
    <form action="./ingresar.php" method ="POST" class="form-box animated fadeInUp" >
    <h1 class="form-title">Token caducado</h1>
        <button type="submit" name = "codigo">
            Salir
        </button>
    </form>
    
</body>
</html>