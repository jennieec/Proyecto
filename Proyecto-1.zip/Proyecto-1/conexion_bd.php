<?php 

$host = "nemonico.com.mx";
$user = "sepherot_jonathan";
$clave = "fL9WD0vDyZ";
$bd = "sepherot_jonathanBD";

$conectar = mysqli_connect($host, $user, $clave,$bd);


?>